@extends('pastries.layout')

@section('content')

@if($errors->any())
    <div class="alert alert-danger">
        <ul>
        @foreach($errors->all() as $error)

            <li>{{ $error }}</li>

        @endforeach
        </ul>
    </div>
@endif

<div class="card mt-4">
	<div class="card-body">

        <h5 class="card-title fw-bolder mb-3">Tambah pastries</h5>

		<form method="post" action="{{ route('coffee.store') }}">
			@csrf
            <div class="mb-3">
                <label for="id_pastries" class="form-label">id_pastries</label>
                <input type="text" class="form-control" id="id_pastries" name="id_pastries">
            </div>
			<div class="mb-3">
                <label for="nama_pastries" class="form-label">nama_pastries</label>
                <input type="text" class="form-control" id="nama_pastries" name="nama_pastries">
            </div>
            <div class="mb-3">
                <label for="harga_pastries" class="form-label">harga_pastries</label>
                <input type="text" class="form-control" id="harga_pastries" name="harga_pastries">
            </div>
			<div class="text-center">
				<input type="submit" class="btn btn-primary" value="Tambah" />
			</div>
		</form>
	</div>
</div>

@stop