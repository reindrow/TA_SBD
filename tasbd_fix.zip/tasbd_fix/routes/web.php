<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CoffeeController;
use App\Http\Controllers\PaketController;
use App\Http\Controllers\PastriesController;
use App\Http\Controllers\DetailController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('admin.index');
// });

Route::get('/user', [UserController::class, 'index'])->name('user.index');
Route::get('/user.add', [UserController::class, 'create'])->name('user.create');
Route::post('/user.store', [UserController::class, 'store'])->name('user.store');
Route::get('/user.edit/{id}', [UserController::class, 'edit'])->name('user.edit');
Route::post('/user.update/{id}', [UserController::class, 'update'])->name('user.update');
Route::post('/user.delete/{id}', [UserController::class,'delete'])->name('user.delete');
Route::post('/user.softdelete/{id}', [UserController::class,'softdelete'])->name('user.softdelete');
Route::get('/user.search', [UserController::class,'search'])->name('user.search');

Route::get('//coffee', [CoffeeController::class, 'index'])->name('coffee.index');
Route::get('/coffee.add', [CoffeeController::class, 'create'])->name('coffee.create');
Route::post('/coffee.store', [CoffeeController::class, 'store'])->name('coffee.store');
Route::get('/coffee.edit/{id}', [CoffeeController::class, 'edit'])->name('coffee.edit');
Route::post('/coffee.update/{id}', [CoffeeController::class, 'update'])->name('coffee.update');
Route::post('/coffee.delete/{id}', [CoffeeController::class,'delete'])->name('coffee.delete');
Route::post('/coffee.softdelete/{id}', [CoffeeController::class,'softdelete'])->name('coffee.softdelete');
Route::get('/coffee.search', [CoffeeController::class,'search'])->name('coffee.search');

Route::get('/paket', [PaketController::class, 'index'])->name('paket.index');
Route::get('/paket.add', [PaketController::class, 'create'])->name('paket.create');
Route::post('/paket.store', [PaketController::class, 'store'])->name('paket.store');
Route::get('/paket.edit/{id}', [PaketController::class, 'edit'])->name('paket.edit');
Route::post('/paket.update/{id}', [PaketController::class, 'update'])->name('paket.update');
Route::post('/paket.delete/{id}', [PaketController::class,'delete'])->name('paket.delete');
Route::post('/paket.softdelete/{id}', [PaketController::class,'softdelete'])->name('paket.softdelete');
Route::get('/paket.search', [PaketController::class,'search'])->name('paket.search');

Route::get('/pastries', [PastriesController::class, 'index'])->name('pastries.index');
Route::get('/pastries.add', [PastriesController::class, 'create'])->name('pastries.create');
Route::post('/pastries.store', [PastriesController::class, 'store'])->name('pastries.store');
Route::get('/pastries.edit/{id}', [PastriesController::class, 'edit'])->name('pastries.edit');
Route::post('/pastries.update/{id}', [PastriesController::class, 'update'])->name('pastries.update');
Route::post('/pastries.delete/{id}', [PastriesController::class,'delete'])->name('pastries.delete');
Route::post('/pastries.softdelete/{id}', [PastriesController::class,'softdelete'])->name('pastries.softdelete');
Route::get('/pastries.search', [PastriesController::class,'search'])->name('pastries.search');

Route::get('/detail', [DetailController::class, 'index'])->name('detail.index');

Route::get('/', [LoginController::class, 'index'])->name('login.index');
Route::post('/', [LoginController::class, 'authenticate'])->name('login.authenticate');
Route::get('/logout', [LoginController::class, 'logout']);

Route::get('/register', [RegisterController::class, 'index'])->name('register.index');
Route::post('/register', [RegisterController::class, 'store'])->name('register.store');


