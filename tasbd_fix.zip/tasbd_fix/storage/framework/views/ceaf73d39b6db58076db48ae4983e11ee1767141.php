

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card mt-4">
	<div class="card-body">

        <h5 class="card-title fw-bolder mb-3">Tambah pastries</h5>

		<form method="post" action="<?php echo e(route('coffee.store')); ?>">
			<?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="id_pastries" class="form-label">id_pastries</label>
                <input type="text" class="form-control" id="id_pastries" name="id_pastries">
            </div>
			<div class="mb-3">
                <label for="nama_pastries" class="form-label">nama_pastries</label>
                <input type="text" class="form-control" id="nama_pastries" name="nama_pastries">
            </div>
            <div class="mb-3">
                <label for="harga_pastries" class="form-label">harga_pastries</label>
                <input type="text" class="form-control" id="harga_pastries" name="harga_pastries">
            </div>
			<div class="text-center">
				<input type="submit" class="btn btn-primary" value="Tambah" />
			</div>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pastries.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasbd_fix\resources\views/pastries/add.blade.php ENDPATH**/ ?>