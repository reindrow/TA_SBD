

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card mt-4">
	<div class="card-body">

        <h5 class="card-title fw-bolder mb-3">Ubah Data Coffee</h5>

		<form method="post" action="<?php echo e(route('coffee.update', $data->id_coffee)); ?>">
			<?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="id_coffee" class="form-label">id_coffee</label>
                <input type="text" class="form-control" id="id_coffee" name="id_coffee" value="<?php echo e($data->id_coffee); ?>">
            </div>
			<div class="mb-3">
                <label for="nama_coffee" class="form-label">nama_coffee</label>
                <input type="text" class="form-control" id="nama_coffee" name="nama_coffee" value="<?php echo e($data->nama_coffee); ?>">
            </div>
            <div class="mb-3">
                <label for="harga_coffee" class="form-label">harga_coffee</label>
                <input type="text" class="form-control" id="harga_coffee" name="harga_coffee" value="<?php echo e($data->harga_coffee); ?>">
            </div>
			<div class="text-center">
				<input type="submit" class="btn btn-primary" value="Ubah" />
			</div>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('coffee.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasbd_fix\resources\views/coffee/edit.blade.php ENDPATH**/ ?>