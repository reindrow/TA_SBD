

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li><?php echo e($error); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card mt-4">
	<div class="card-body">

        <h5 class="card-title fw-bolder mb-3">Ubah Data Paket</h5>

		<form method="post" action="<?php echo e(route('paket.update', $data->id_paket)); ?>">
			<?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="id_paket" class="form-label">id_paket</label>
                <input type="text" class="form-control" id="id_paket" name="id_paket" value="<?php echo e($data->id_paket); ?>">
            </div>
			<div class="mb-3">
                <label for="nama_paket" class="form-label">nama_paket</label>
                <input type="text" class="form-control" id="nama_paket" name="nama_paket" value="<?php echo e($data->nama_paket); ?>">
            </div>
            <div class="mb-3">
                <label for="harga_paket" class="form-label">harga_paket</label>
                <input type="text" class="form-control" id="harga_paket" name="harga_paket" value="<?php echo e($data->harga_paket); ?>">
            </div>
            <div class="mb-3">
                <label for="id_coffee" class="form-label">id_coffee</label>
                <input type="text" class="form-control" id="id_coffee" name="id_coffee" value="<?php echo e($data->id_coffee); ?>">
            </div>
            <div class="mb-3">
                <label for="id_pastries" class="form-label">id_pastries</label>
                <input type="text" class="form-control" id="id_pastries" name="id_pastries" value="<?php echo e($data->id_pastries); ?>">
            </div>
			<div class="text-center">
				<input type="submit" class="btn btn-primary" value="Ubah" />
			</div>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('paket.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasbd_fix\resources\views/paket/edit.blade.php ENDPATH**/ ?>