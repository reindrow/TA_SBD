<?php

namespace App\Http\Controllers;

use App\Models\Coffee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class CoffeeController extends Controller
{
    public function index() {
        $datas = DB::select('select * from coffee');

        return view('coffee.index')
            ->with('datas', $datas);
    }

    public function create() {
        return view('coffee.add');
    }

    public function store(Request $request) {
        $request->validate([
            'id_coffee' => 'required',
            'nama_coffee' => 'required',
            'harga_coffee' => 'required',
        ]);

        // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
        DB::insert('INSERT INTO admin(id_coffee, nama_coffee, harga_coffee) VALUES (:id_coffee, :nama_coffee, :harga_coffee)',
        [
            'id_coffee' => $request->id_coffee,
            'nama_coffee' => $request->nama_coffee,
            'harga_coffee' => $request->harga_coffee,
        ]
        );

        // Menggunakan laravel eloquent
        // coffee::create([
        //    'id_coffee' => $request->id_coffee,
        //    'nama_coffee' => $request->nama_coffee,
        //    'harga_coffee' => $request->harga_coffee,
        // ]);

        return redirect()->route('coffee.index')->with('success', 'Data coffee berhasil disimpan');
    }

    public function edit($id) {
        $data = DB::table('coffee')->where('id_coffee', $id)->first();

        return view('coffee.edit')->with('data', $data);
    }

    public function update($id, Request $request) {
        $request->validate([
            'id_coffee' => 'required',
            'nama_coffee' => 'required',
            'harga_coffee' => 'required',
        ]);

        // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
        DB::update('UPDATE coffee SET id_coffee = :id_coffee, nama_coffee = :nama_coffee, harga_coffee = :harga_coffee WHERE id_coffee = :id',
        [
            'id' => $id,
            'id_coffee' => $request->id_coffee,
            'nama_coffee' => $request->nama_coffee,
            'harga_coffee' => $request->harga_coffee,
        ]
        );

        // Menggunakan laravel eloquent
        // coffee::where('id_coffee', $id)->update([
        //    'id_coffee' => $request->id_coffee,
        //    'nama_coffee' => $request->nama_coffee,
        //    'harga_coffee' => $request->harga_coffee,
        // ]);

        return redirect()->route('coffee.index')->with('success', 'Data coffee berhasil diubah');
    }

    public function delete($id) {
        // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
        DB::delete('DELETE FROM coffee WHERE id_coffee = :id_coffee', ['id_coffee' => $id]);

        // Menggunakan laravel eloquent
        // coffee::where('id_coffee', $id)->delete();

        return redirect()->route('coffee.index')->with('success', 'Data coffee berhasil dihapus');
    }
    public function search(Request $request) {
        if($request->has('search')){
            $datas = DB::table('coffee')->where('id_coffee', 'LIKE', $request->search )->get();
        }else{
            $datas = DB::select('select * from coffee');
        }
        return view('coffee.index')->with('datas',$datas);
}
public function softdelete($id) {
    // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
    DB::update(' update coffee set deleted_at = 1 WHERE id_coffee = :id_coffee', ['id_coffee' => $id]);

    // Menggunakan laravel eloquent
    // Hp::where('id_coffee', $id)->delete();

    return redirect()->route('coffee.index')->with('success', 'Data Coffee berhasil dihapus');
}
}

