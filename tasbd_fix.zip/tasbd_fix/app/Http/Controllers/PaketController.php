<?php

namespace App\Http\Controllers;

use App\Models\paket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class PaketController extends Controller
{
    public function index() {
        $datas = DB::select('select * from paket');

        return view('paket.index')
            ->with('datas', $datas);
    }

    public function create() {
        return view('paket.add');
    }

    public function store(Request $request) {
        $request->validate([
            'id_paket' => 'required',
            'nama_paket' => 'required',
            'harga_paket' => 'required',
            'id_coffee' => 'required',
            'id_pastries' => 'required',
        ]);

        // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
        DB::insert('INSERT INTO admin(id_paket, nama_paket, harga_paket, id_coffe, id_pastries) VALUES (:id_paket, :nama_paket, :harga_paket, :id_coffe, :id_pastries)',
        [
            'id_paket' => $request->id_paket,
            'nama_paket' => $request->nama_paket,
            'harga_paket' => $request->harga_paket,
            'id_coffee' => $request->nama_coffee,
            'id_pastries' => $request->harga_pastries,
        ]
        );

        // Menggunakan laravel eloquent
        // paket::create([
        //    'id_paket' => $request->id_paket,
        //    'nama_paket' => $request->nama_paket,
        //    'harga_paket' => $request->harga_paket,
        //    'id_coffee' => $request->nama_coffee,
        //    'id_pastries' => $request->harga_pastries,
        // ]);

        return redirect()->route('paket.index')->with('success', 'Data paket berhasil disimpan');
    }

    public function edit($id) {
        $data = DB::table('paket')->where('id_paket', $id)->first();

        return view('paket.edit')->with('data', $data);
    }

    public function update($id, Request $request) {
        $request->validate([
            'id_paket' => 'required',
            'nama_paket' => 'required',
            'harga_paket' => 'required',
            'id_coffee' => 'required',
            'id_pastries' => 'required',
        ]);

        // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
        DB::update('UPDATE paket SET id_paket = :id_paket, nama_paket = :nama_paket, harga_paket = :harga_paket, id_coffee = :id_coffee, id_pastries = :id_pastries WHERE id_paket = :id',
        [
            'id_paket' => $request->id_paket,
            'nama_paket' => $request->nama_paket,
            'harga_paket' => $request->harga_paket,
            'id_coffee' => $request->nama_coffee,
            'id_pastries' => $request->harga_pastries,
        ]
        );

        // Menggunakan laravel eloquent
        // paket::where('id_paket', $id)->update([
        //    'id_paket' => $request->id_paket,
        //    'nama_paket' => $request->nama_paket,
        //    'harga_paket' => $request->harga_paket,
        //    'id_coffee' => $request->nama_coffee,
        //    'id_pastries' => $request->harga_pastries,
        // ]);

        return redirect()->route('paket.index')->with('success', 'Data paket berhasil diubah');
    }

    public function delete($id) {
        // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
        DB::delete('DELETE FROM paket WHERE id_paket = :id_paket', ['id_paket' => $id]);

        // Menggunakan laravel eloquent
        // paket::where('id_paket', $id)->delete();

        return redirect()->route('paket.index')->with('success', 'Data paket berhasil dihapus');
    }
    public function search(Request $request) {
        if($request->has('search')){
            $datas = DB::table('paket')->where('id_paket', 'LIKE', $request->search )->get();
        }else{
            $datas = DB::select('select * from paket');
        }
        return view('paket.index')->with('datas',$datas);
}
    
public function softdelete($id) {
            // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
            DB::update(' update paket set deleted_at = 1 WHERE id_paket = :id_paket', ['id_paket' => $id]);
        
            // Menggunakan laravel eloquent
            // Hp::where('id_paket', $id)->delete();
        
            return redirect()->route('paket.index')->with('success', 'Data Paket berhasil dihapus');
        }

}