<?php

namespace App\Http\Controllers;

use App\Models\pastries;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class PastriesController extends Controller
{
    public function index() {
        $datas = DB::select('select * from pastries');

        return view('pastries.index')
            ->with('datas', $datas);
    }

    public function create() {
        return view('pastries.add');
    }

    public function store(Request $request) {
        $request->validate([
            'id_pastries' => 'required',
            'nama_pastries' => 'required',
            'harga_pastries' => 'required',
        ]);

        // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
        DB::insert('INSERT INTO admin(id_pastries, nama_pastries, harga_pastries) VALUES (:id_pastries, :nama_pastries, :harga_pastries)',
        [
            'id_pastries' => $request->id_pastries,
            'nama_pastries' => $request->nama_pastries,
            'harga_pastries' => $request->harga_pastries,
        ]
        );

        // Menggunakan laravel eloquent
        // pastries::create([
        //    'id_pastries' => $request->id_pastries,
        //    'nama_pastries' => $request->nama_pastries,
        //    'harga_pastries' => $request->harga_pastries,
        // ]);

        return redirect()->route('pastries.index')->with('success', 'Data pastries berhasil disimpan');
    }

    public function edit($id) {
        $data = DB::table('pastries')->where('id_pastries', $id)->first();

        return view('pastries.edit')->with('data', $data);
    }

    public function update($id, Request $request) {
        $request->validate([
            'id_pastries' => 'required',
            'nama_pastries' => 'required',
            'harga_pastries' => 'required',
        ]);

        // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
        DB::update('UPDATE pastries SET id_pastries = :id_pastries, nama_pastries = :nama_pastries, harga_pastries = :harga_pastries WHERE id_pastries = :id',
        [
            'id' => $id,
            'id_pastries' => $request->id_pastries,
            'nama_pastries' => $request->nama_pastries,
            'harga_pastries' => $request->harga_pastries,
        ]
        );

        // Menggunakan laravel eloquent
        // pastries::where('id_pastries', $id)->update([
        //    'id_pastries' => $request->id_pastries,
        //    'nama_pastries' => $request->nama_pastries,
        //    'harga_pastries' => $request->harga_pastries,
        // ]);

        return redirect()->route('pastries.index')->with('success', 'Data pastries berhasil diubah');
    }

    public function delete($id) {
        // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
        DB::delete('DELETE FROM pastries WHERE id_pastries = :id_pastries', ['id_pastries' => $id]);

        // Menggunakan laravel eloquent
        // pastries::where('id_pastries', $id)->delete();

        return redirect()->route('pastries.index')->with('success', 'Data pastries berhasil dihapus');
    }
    public function search(Request $request) {
        if($request->has('search')){
            $datas = DB::table('pastries')->where('id_pastries', 'LIKE', $request->search )->get();
        }else{
            $datas = DB::select('select * from pastries');
        }
        return view('pastries.index')->with('datas',$datas);
}
    
public function softdelete($id) {
            // Menggunakan Query Builder Laravel dan Named Bindings untuk valuesnya
            DB::update(' update pastries set deleted_at = 1 WHERE id_pastries = :id_pastries', ['id_pastries' => $id]);
        
            // Menggunakan laravel eloquent
            // Hp::where('id_pastries', $id)->delete();
        
            return redirect()->route('pastries.index')->with('success', 'Data Pastries berhasil dihapus');
        }

}